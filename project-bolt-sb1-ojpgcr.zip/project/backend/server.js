import express from 'express';
import cors from 'cors';
import multer from 'multer';
import dotenv from 'dotenv';
import { spawn } from 'child_process';
import ffmpeg from 'ffmpeg-static';
import axios from 'axios';
import { Readable } from 'stream';
import { Model, KaldiRecognizer } from 'vosk';

dotenv.config();

const app = express();
const upload = multer({ storage: multer.memoryStorage() });

app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  methods: ['GET', 'POST'],
  credentials: true
}));

app.use(express.json());

// Initialize Vosk model
const VOSK_MODEL_PATH = './model'; // Download Japanese model from https://alphacephei.com/vosk/models
const model = new Model(VOSK_MODEL_PATH);

async function convertVideoToAudio(videoBuffer) {
  return new Promise((resolve, reject) => {
    const ffmpegProcess = spawn(ffmpeg, [
      '-i', 'pipe:0',
      '-ar', '16000',
      '-ac', '1',
      '-f', 'wav',
      'pipe:1'
    ]);

    const chunks = [];
    ffmpegProcess.stdout.on('data', chunk => chunks.push(chunk));
    ffmpegProcess.stdout.on('end', () => resolve(Buffer.concat(chunks)));
    ffmpegProcess.on('error', reject);

    const videoStream = new Readable();
    videoStream.push(videoBuffer);
    videoStream.push(null);
    videoStream.pipe(ffmpegProcess.stdin);
  });
}

async function transcribeAudio(audioBuffer) {
  const rec = new KaldiRecognizer(model, 16000);
  rec.setWords(true);

  let finalResult = '';
  const chunkSize = 4000;
  
  for (let i = 0; i < audioBuffer.length; i += chunkSize) {
    const chunk = audioBuffer.slice(i, i + chunkSize);
    const end = i + chunkSize >= audioBuffer.length;
    
    if (rec.acceptWaveform(chunk)) {
      const result = JSON.parse(rec.result());
      if (result.text) {
        finalResult += result.text + ' ';
      }
    }
    
    if (end) {
      const result = JSON.parse(rec.finalResult());
      if (result.text) {
        finalResult += result.text;
      }
    }
  }
  
  return finalResult.trim();
}

async function translateText(text) {
  try {
    const response = await axios.post('https://libretranslate.de/translate', {
      q: text,
      source: 'ja',
      target: 'fr',
      format: 'text'
    });
    return response.data.translatedText;
  } catch (error) {
    console.error('Translation error:', error);
    throw new Error('Failed to translate text');
  }
}

app.post('/api/translate-video', upload.single('video'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Aucun fichier vidéo fourni' });
    }

    const audioBuffer = await convertVideoToAudio(req.file.buffer);
    const transcription = await transcribeAudio(audioBuffer);
    const translation = await translateText(transcription);

    res.json({
      transcription,
      translation
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Erreur lors du traitement de la vidéo' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});