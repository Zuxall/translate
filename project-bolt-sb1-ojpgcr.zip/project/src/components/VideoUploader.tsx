import React from 'react';
import { Upload } from 'lucide-react';

interface VideoUploaderProps {
  videoFile: File | null;
  onFileUpload: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

const VideoUploader: React.FC<VideoUploaderProps> = ({ videoFile, onFileUpload }) => {
  return (
    <div className="mb-8">
      <label className="flex flex-col items-center justify-center h-48 border-2 border-dashed border-indigo-300 rounded-lg cursor-pointer hover:bg-indigo-50 transition-colors">
        <Upload className="w-12 h-12 text-indigo-500 mb-2" />
        <span className="text-indigo-600 font-medium">
          {videoFile ? videoFile.name : 'Cliquez pour télécharger une vidéo'}
        </span>
        <input
          type="file"
          accept="video/*"
          onChange={onFileUpload}
          className="hidden"
        />
      </label>
    </div>
  );
};

export default VideoUploader;