import React, { useState, useRef } from 'react';
import { Upload, Play, Pause, Languages, Download, Loader2 } from 'lucide-react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import VideoPlayer from './components/VideoPlayer';
import TranslationResults from './components/TranslationResults';
import VideoUploader from './components/VideoUploader';

function App() {
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [translation, setTranslation] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setVideoFile(file);
      const videoUrl = URL.createObjectURL(file);
      if (videoRef.current) {
        videoRef.current.src = videoUrl;
      }
      setTranscription('');
      setTranslation('');
    }
  };

  const processVideo = async () => {
    if (!videoFile) {
      toast.error('Veuillez d\'abord télécharger une vidéo');
      return;
    }

    setIsProcessing(true);
    try {
      // Simulated API call - replace with actual backend call
      await new Promise(resolve => setTimeout(resolve, 2000));
      setTranscription('これは日本語のテキストです。');
      setTranslation('Ceci est un texte en japonais.');
      toast.success('Traduction terminée avec succès!');
    } catch (error) {
      console.error('Processing error:', error);
      toast.error('Une erreur est survenue lors du traitement');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 to-purple-100 p-8">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-12">
          <h1 className="text-4xl font-bold text-indigo-900 mb-4">
            Traducteur Vidéo Japonais-Français
          </h1>
          <p className="text-lg text-gray-600">
            Téléchargez une vidéo en japonais pour obtenir sa traduction en français
          </p>
        </header>

        <div className="bg-white rounded-xl shadow-xl p-8 mb-8">
          <VideoUploader
            videoFile={videoFile}
            onFileUpload={handleFileUpload}
          />

          {videoFile && (
            <>
              <VideoPlayer
                videoRef={videoRef}
                isPlaying={isPlaying}
                setIsPlaying={setIsPlaying}
              />

              <div className="flex justify-center mb-8">
                <button
                  onClick={processVideo}
                  disabled={isProcessing}
                  className="flex items-center px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:bg-gray-400"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Traitement en cours...
                    </>
                  ) : (
                    <>
                      <Languages className="w-5 h-5 mr-2" />
                      Traduire la vidéo
                    </>
                  )}
                </button>
              </div>

              <TranslationResults
                transcription={transcription}
                translation={translation}
              />
            </>
          )}
        </div>
      </div>
      <ToastContainer position="bottom-right" />
    </div>
  );
}

export default App;